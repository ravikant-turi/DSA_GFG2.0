package com.java.lms.model;

public enum LeaveStatus {
	PENDING, ACCEPTED, REJECTED
}